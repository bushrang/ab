   <!-- FOOTER -->
   
      </div><!-- /.container -->
      
       <section>
       <hr class="footercut">
 <div class="container-fluid primary-footer">
     <div class="col-lg-6">
     	<?php dynamic_sidebar( 'footer_left' ); ?>
     </div>
      <div class="col-lg-6 pull-right">
     	
     </div>
 </div>
 </section>
 
      <div class="container-fluid copy-footer" style="padding-bottom:20px">
      	<footer>
      	<div class="container">
        <!-- <p class="pull-right"><a href="#">Back to top</a></p> -->
        <small>&copy; 2016 Adbites GmbH &middot; <?php bloginfo('description'); ?></small>
      	</div>
      </footer>
      </div><!-- .container-fluid -->
      

    
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>    
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/assets/js/ie10-viewport-bug-workaround.js"></script>
     <script src="<?php bloginfo('template_url'); ?>/js/scroll-top.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/headroom.min.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/TweenMax.min.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/ScrollMagic.min.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/debug.addIndicators.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/animation.gsap.min.js"></script>
	 <script src="<?php bloginfo('template_url'); ?>/js/antimoderate.min.js"></script>

	 <script src="<?php bloginfo('template_url'); ?>/js/mainnew.js"></script>
	 
	 
	

<!-- Scroll Top -->
<script type="text/javascript">
 
   $(document).ready(function(){
 
      $('.top').UItoTop();
 
   });
 
</script>

<!-- Change Menu Color -->

<script type="text/javascript">
$(document).ready(function(){       
   var scroll_start = 0;
   var startchange = $('.navcolchange');
   var offset = startchange.offset();
    if (startchange.length){
   $(document).scroll(function() { 
      scroll_start = $(this).scrollTop();
      if(scroll_start > offset.top) {
          $(".navbar-inverse").css('background-color', '#000000');
       } else {
          $('.navbar-inverse').css('background-color', 'transparent');
       }
   });
    }
});

</script>

          
             
   <!-- HeadRoom  -->

               <script src="http://Booking:8888/ressources/themes/adbites/js/headroom.min.js"></script>   
   
    <style type="text/css">
    .headroom {position: fixed;top: 0;left: 0;right: 0;transition: all .2s ease-in-out;}
    .headroom--unpinned {top: -100px;}
    .headroom--pinned {top: 0;}
    </style>
    
   <script  type="text/javascript"  src="https://rawgithub.com/WickyNilliams/headroom.js/master/dist/headroom.js"></script>      
   <script  type="text/javascript"  src="https://rawgithub.com/WickyNilliams/headroom.js/master/src/jQuery.headroom.js"></script>
    <script type="text/javascript">
        $(".navbar-fixed-top").headroom();
    </script>
   <!-- HeadRoom  -->
   

<script type="text/javascript">

$(function() {
    // Init Controller
    var scrollMagicController = new ScrollMagic();
});

</script>

<script type="text/javascript">

 function isIE () {
    var myNav = navigator.userAgent.toLowerCase();
    return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
}

window.isIEOld = isIE() && isIE() < 9;
window.isiPad = navigator.userAgent.match(/iPad/i);

var img = $('.video').data('placeholder'),
    video = $('.video').data('video'),
    noVideo = $('.video').data('src'),
    el = '';

if($(window).width() > 599 && !isIEOld && !isiPad) {
    el +=   '<video autoplay loop poster="' + img + '">';
    el +=       '<source src="' + video + '" type="video/mp4">';
    el +=   '</video>';
} else {
    el = '<div class="video-element" style="background-image: url(' + noVideo + ')"></div>';
}

$('.video').prepend(el);
 </script>   
 
  <script src="<?php bloginfo('template_url'); ?>/js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
              
 
<!-- Antimoderate              -->
<!--
 <script>
 
var img = document.getElementById('antim');
 
 
AntiModerate.process(img, img.getAttribute("data-antimoderate-idata"));
 
</script>  
--> 

<!-- Midnight -->

<script src="<?php bloginfo('template_url'); ?>/js/midnight.jquery.min.js"></script>
<script>
  // Start midnight
  $(document).ready(function(){
    // Change this to the correct selector for your nav.
    $('nav.fixed').midnight();
  });
</script>       
 

</body>
</html>

