<?php get_header(); ?>

	<div class="navcolchange"></div>	
<!-- Blog Post Content Column -->
<?php the_post(); ?>
<div class="container">
<div class="row">
<div class="col-lg-12"
<?php if ( function_exists('yoast_breadcrumb') ) 
{yoast_breadcrumb('<p id="breadcrumbs">','</p>');} ?>
</div>
</div>
<div class="row" style="padding-top:5%">
             	<div class="col-lg-2">
             		
             	</div>
             	<div class="col-lg-8">
             	<p class="blogcategorysmall"><?php
foreach((get_the_category()) as $category) { 
    echo $category->category_nicename . ' '; 
} 
?></p>
             		<h1 class="blogtitle"><?php the_title(); ?></h1>
             	</div>
             	<div class="col-lg-2">
             		
             	</div>
             </div><!-- .row -->  

</div>
<div class="container-fluid blogheadimg">
<div class="row">
             	<div class="col-lg-2">
             		
             	</div>
             	<div class="col-lg-8">
             	<h2 class="bloglead text-center" style="color:#ffffff"><?php echo get_post_meta($post->ID, 'wisdom', true); ?></h2>

             		
             	</div>
             	<div class="col-lg-2">
             		
             	</div>
             </div>   
</div>	
	
		<div class="container">
		<div class="row">
		

                <!-- Blog Post -->

                <!-- Author -->
                <p class="lead">
                    <!-- by <a href="#">Start Bootstrap</a> -->
                </p>


                <!-- Date/Time -->
                <!-- <p><span class="glyphicon glyphicon-time"></span> Posted on August 24, 2013 at 9:00 PM</p> -->

                <!-- Post Content -->
                      
            <div class="container">
             <div class="row">
             	<div class="col-lg-2">
             		
             	</div>
             	<div class="col-lg-8">
             	<p class="lead"><?php echo get_post_meta($post->ID, 'lead', true); ?></p>
             	
             		<p><?php the_content(); ?></p>
</div>

             		
             	</div>
             	<div class="col-lg-2">
             		
             	</div>
             </div><!-- .row -->   
            </div>

                           </div>	
                           <?php comments_template(); ?>



		
<?php get_footer(); ?>