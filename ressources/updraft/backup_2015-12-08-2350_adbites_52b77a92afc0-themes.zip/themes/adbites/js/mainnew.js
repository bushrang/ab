/* Animate Home */


var controller = new ScrollMagic.Controller();

var scene1 = new ScrollMagic.Scene({
triggerElement: '#trigger1'
}) .setTween('#animate1', 0.5, {scale: 1.2})
/* .addIndicators({name: "1 - no duration"}) */
.addTo(controller);


TweenMax.from(".chevronhome", 2.5, {y: -50, opacity:0, delay:2, ease:Power1.easeOut, force3D:false, repeat:500}, 0.2);



/* TweenMax.from(".caseovertitleani", 1, {y: 50, opacity:0, delay:1, ease:Power1.easeOut, force3D:false}, 0.2); */


/* Animate Case */



TweenMax.from(".homefatani1", 1, {y: 50, opacity:0, delay:2, ease:Power1.easeOut, force3D:false}, 0.2);
TweenMax.from(".homefatani2", 1, {y: 50, opacity:0, delay:3, ease:Power1.easeOut, force3D:false}, 0.2);


TweenMax.from(".homeleadani", 1, {y: 50, opacity:0, delay:5, ease:Power1.easeOut, force3D:false}, 0.2);





var casescene1 = new ScrollMagic.Scene({
triggerElement: '#trigger1'
}) .setTween('#casechallengeh2_1', 0.5, {opacity: 0.1, y: 100})
/* .addIndicators({name: "1 - no duration"}) */
.addTo(controller);



TweenMax.from(".casetitleani", 1, {scale:1, opacity:0, delay:0.8, ease:Power1.easeOut, force3D:false, y:0}, 0.2);




TweenMax.staggerFrom(".projani", 1, {scale:0.5, opacity:0, delay:1.5, ease:Back.easeOut.config(1.7), force3D:true, y:100}, 0.2);

$(".btn").click(function(){
  TweenMax.staggerTo(".projani", 0.5, {opacity:0, y:-100, ease:Back.easeIn}, 0.1);
});


/* Animate Case Overview */


TweenMax.from(".caseovertitleani", 1, {y: 50, opacity:0, delay:1, ease:Power1.easeOut, force3D:false}, 0.2);

TweenMax.from(".caseoversep", 1, {y: 50, opacity:0, delay:1.5, ease:Power1.easeOut, force3D:false}, 0.2);

TweenMax.from(".caseovertextani", 1, {y: 50, opacity:0, delay:2, ease:Power1.easeOut, force3D:false}, 0.2);


TweenMax.staggerFrom(".caseoverani", 1, {y: 50, opacity:0, delay:2.5, ease:Power1.easeOut, force3D:false}, 0.2);

$(".btn").click(function(){
  TweenMax.staggerTo(".caseoverani", 0.5, {opacity:0, y:-100, ease:Back.easeIn}, 0.1);
});