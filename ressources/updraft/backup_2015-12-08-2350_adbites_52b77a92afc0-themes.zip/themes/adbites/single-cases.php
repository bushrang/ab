<?php get_header(); ?>
	<div class="navcolchange"></div>	
<!-- Large Case Header -->
<?php the_post(); ?>
<div class="container">
<div class="row">
             	<div class="col-lg-2">
             		
             	</div>
             	<div class="col-lg-8">
             	</div>
             	<div class="col-lg-2">
             		
             	</div>
             </div><!-- .row -->  

</div>
<div class="container-fluid caseheadimg">
<div class="row">
             	<div class="col-lg-2">
             		
             	</div>
             	<div class="col-lg-8">
			 	<h1 class="casetitle text-center casetitleani" style="color:#ffffff"><?php the_title(); ?></h1>
             		
             	</div>
             	<div class="col-lg-2">
             		
             	</div>
             </div>  
<div class="row projectattributes">

			<div class="col-md-2 hidden-sm">
			</div>
			<div class="col-md-2 col-sm-3 col-xs-4 projectattr1 projani">
			<p style="color:#ffffff;font-weight:700;">Kunde</p>
			 	<p style="color:#ffffff; font-size:11px"><?php the_field('kunde-projecattr'); ?></p>
			</div>
			<div class="col-md-2 col-sm-3 col-xs-4 projectattr2 projani">
			<p style="color:#ffffff;font-weight:700;">Vertical</p>
             	<p style="color:#ffffff; font-size:11px"><?php the_field('vertical-projecattr'); ?></p>
			</div>
			<div class="col-md-2 col-sm-3 col-xs-4 projectattr3 projani">
			<p style="color:#ffffff;font-weight:700;">Keyservices</p>
             	<p style="color:#ffffff; font-size:11px"><?php the_field('keyservices-projecattr'); ?></p>
			</div>
			<div class="col-md-2 col-sm-3 hidden-xs projectattr4 projani">
			<p style="color:#ffffff;font-weight:700;">Keyservices</p>
             	<p style="color:#ffffff; font-size:11px"><?php the_field('keyservices-projecattr'); ?></p>
			</div>
			<div class="col-md-2 hidden-sm">
			</div>
 
</div>
</div>

<!-- The Challenge -->
<div class="container challenge">

<div class="col-lg-2">
	
</div>
<div class="col-lg-8 text-center">
	<h2 class="challengetitle wow fadeInUp" data-wow-offset="250" data-wow-duration="2s">Die Challenge</h2>
	  <hr class="post-header-regular wow fadeInUp" data-wow-offset="250" data-wow-duration="2s">

	<p class="wow fadeInUp" data-wow-offset="250" data-wow-duration="2s"><?php the_field('challenge'); ?></p>
<!-- Get Challenge-Image from database -->
	<?php 

$image = get_field('challengebild1');

if( !empty($image) ): ?>

	<img class="img-responsive wow fadeInUp" data-wow-offset="250" data-wow-duration="2s" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />

<?php endif; ?>
<!-- Challenge-Image End -->

</div>
<div class="col-lg-2">
	
</div>


</div>

<!-- Our approach -->

<div class="container-fluid caseapproach" style="background-image: url('<?php the_field('ansatz_background'); ?>');">
	<div class="container">
 <div class="row">
 <div class="col-lg-6">
 	<h2 class="wow fadeInUp" data-wow-offset="250" data-wow-duration="2s" style="color:#fff">Unser Ansatz</h2>
 	  <hr class="post-header-regularwt wow fadeInUp" data-wow-offset="250" data-wow-duration="2s" style="margin: 0 0 17px;">
 	<p class="wow fadeInUp" data-wow-offset="250" data-wow-duration="2s"><?php the_field('ansatz'); ?></p>
 </div>
  <div class="col-lg-6"></div>
 </div>
 </div>
</div>
 
 <!-- End approach -->
 
 <!-- Services -->
 
 
 <div class="container caseservices">

	 <div class="row">
	 	<div class="col-lg-12 text-center">
	 	      <div class="wrap">  
	 		<h2 class="wow fadeInUp" id="serviceani" data-wow-offset="250" data-wow-duration="2s">Unser Leistungen für <?php the_field('kunde-projecattr'); ?></h2>
	 		<hr class="post-header-regular wow fadeInUp" data-wow-offset="250" data-wow-duration="2s">
	 	</div>
	 <div class="row">
	 		<div class="col-lg-4 wow fadeInUp" data-wow-offset="250" data-wow-duration="2s">
	 			<p><?php the_field('leistung_1'); ?></p>
	 		</div>
	 		<div class="col-lg-4 wow fadeInUp" data-wow-offset="250" data-wow-duration="2s" data-wow-delay="1s">
	 			<p><?php the_field('leistung_2'); ?></p>
	 		</div>
	 		<div class="col-lg-4 wow fadeInUp" data-wow-offset="250" data-wow-duration="2s" data-wow-delay="2s">
	 			<p><?php the_field('leistung_3'); ?></p>
	 		</div>
	 </div>
	 </div>
</div>	


<!-- End Services -->

<!-- Best Posts -->
<div class="container">
	<div class="row">
	<div class="col-lg4">
	<?php the_field('xamplepost_1'); ?>
	</div>
	<div class="col-lg4">
	<?php the_field('xamplepost_2'); ?>
	</div>
	<div class="col-lg4">
	<?php the_field('xamplepost_3'); ?>
	</div>
		
	</div>
	
	</div>
</div>


<!-- End best Posts -->
 
<div class="spacer"></div>
		
<?php get_footer(); ?>